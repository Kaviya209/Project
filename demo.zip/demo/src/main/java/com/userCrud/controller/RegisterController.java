package com.userCrud.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.userCrud.exception.RegisterNotFoundException;
import com.userCrud.exception.UserNotFoundException;
import com.userCrud.model.Register;
import com.userCrud.model.User;
import com.userCrud.repository.RegisterRepository;




@CrossOrigin(origins="http://localhost:4200")
@RestController
@RequestMapping("/api/v1/")

public class RegisterController {
	

	@Autowired
	RegisterRepository registerRepository;
	

	@GetMapping("registers")
	public List<Register> getAllStudent()
	{
		return registerRepository.findAll();
	}
	

	@PostMapping("registers")
	public Register saveRegister(@RequestBody Register register)
	{
		return registerRepository.save(register);
	}
	

    @GetMapping("registers/{id}")
    public ResponseEntity<Register> getRegisterbyId(@PathVariable(value="id")int id)throws RegisterNotFoundException
    {
    	Register register = registerRepository.findById(id).orElseThrow(() -> new RegisterNotFoundException("Register not Exist with ID : "+id));
    	return ResponseEntity.ok().body(register);
    }
    

	@DeleteMapping("registers/{id}")
	public ResponseEntity<Map<String,Boolean>> deleteUser(@PathVariable int id) throws RegisterNotFoundException
	{
		Register register = registerRepository.findById(id).orElseThrow(() -> new RegisterNotFoundException("Register not Exist with ID : "+id));
		registerRepository.delete(register);
		
		Map<String,Boolean> response=new HashMap<>();
		response.put("Deleted",Boolean.TRUE);
		return ResponseEntity.ok(response);
	}
	

	@PutMapping("registers/{id}")
	public ResponseEntity<Register> updateRegister(@PathVariable int id, @RequestBody Register registerDetail) throws RegisterNotFoundException
	{
		Register register = registerRepository.findById(id).orElseThrow(() -> new RegisterNotFoundException("Register not Exist with ID : "+id));
		
		register.setUsername(registerDetail.getUsername());
		register.setFname(registerDetail.getFname());
		register.setLname(registerDetail.getLname());
		register.setEmail(registerDetail.getEmail());
		register.setPassword(registerDetail.getPassword());
		
		Register updatedRegister = registerRepository.save(register);
		return ResponseEntity.ok(updatedRegister);
	}



}
