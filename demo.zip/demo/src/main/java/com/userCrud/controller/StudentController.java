package com.userCrud.controller;


import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.userCrud.exception.StudentNotFoundException;

import com.userCrud.exception.UserNotFoundException;
import com.userCrud.model.Student;

import com.userCrud.repository.StudentRepository;



@CrossOrigin(origins="http://localhost:4200")
@RestController
@RequestMapping("/api/v1/")

public class StudentController {

	@Autowired
	StudentRepository studentRepository;
	

	@GetMapping("students")
	public List<Student> getAllStudent()
	{
		return studentRepository.findAll();
	}

	@PostMapping("students")
	public Student saveStudent(@RequestBody Student student)
	{
		return studentRepository.save(student);
	}
	
    @GetMapping("students/{id}")
    public ResponseEntity<Student> getStudentbyId(@PathVariable(value="id")int id)throws StudentNotFoundException
    {
    	Student student = studentRepository.findById(id).orElseThrow(() -> new StudentNotFoundException("Student not Exist with ID : "+id));
    	return ResponseEntity.ok().body(student);
    }

	@DeleteMapping("students/{id}")
	public ResponseEntity<Map<String,Boolean>> deleteUser(@PathVariable int id) throws StudentNotFoundException
	{
		Student student = studentRepository.findById(id).orElseThrow(() -> new StudentNotFoundException("Student not Exist with ID : "+id));
		studentRepository.delete(student);
		
		Map<String,Boolean> response=new HashMap<>();
		response.put("Deleted",Boolean.TRUE);
		return ResponseEntity.ok(response);
	}
	

	@PutMapping("students/{id}")
	public ResponseEntity<Student> updateStudent(@PathVariable int id, @RequestBody Student studentDetail) throws StudentNotFoundException
	{
		Student student = studentRepository.findById(id).orElseThrow(() -> new StudentNotFoundException("Student not Exist with ID : "+id));
		
		student.setFname(studentDetail.getFname());
		student.setLname(studentDetail.getLname());
		student.setCity(studentDetail.getCity());
		student.setState(studentDetail.getState());
		student.setZip(studentDetail.getZip());
		student.setEmail(studentDetail.getEmail());
		student.setContactnum(studentDetail.getContactnum());
		student.setGender(studentDetail.getGender());
		student.setPrfdays(studentDetail.getPrfdays());
		student.setPrftime(studentDetail.getPrftime());
		student.setDob(studentDetail.getDob());
		student.setCardname(studentDetail.getCardname());
		student.setCardnum(studentDetail.getCardnum());
		student.setExpmonth(studentDetail.getExpmonth());
		student.setExpyear(studentDetail.getExpyear());
		student.setCvvnum(studentDetail.getCvvnum());
		student.setCoursename(studentDetail.getCoursename());
		
		
		Student updatedStudent=studentRepository.save(student);
		return ResponseEntity.ok(updatedStudent);
	}
	
	
}
