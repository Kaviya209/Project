package com.userCrud.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;


@Entity
@Table(name="register")
public class Register {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
  private int registerId;
	@Column(name="username")
	  private String username;
	@Column(name="fname")
		  private String fname;
	@Column(name="lname")
		  private String lname;
	@Column(name="password")
	  private String password;
	@Column(name="email")
	  private String email;
	
	 
	public Register() {
		
	}


	public Register(int registerId, String username, String fname, String lname, String password, String email) {
		super();
		this.registerId = registerId;
		this.username = username;
		this.fname = fname;
		this.lname = lname;
		this.password = password;
		this.email = email;
	}


	public int getRegisterId() {
		return registerId;
	}


	public void setRegisterId(int registerId) {
		this.registerId = registerId;
	}


	public String getUsername() {
		return username;
	}


	public void setUsername(String username) {
		this.username = username;
	}


	public String getFname() {
		return fname;
	}


	public void setFname(String fname) {
		this.fname = fname;
	}


	public String getLname() {
		return lname;
	}


	public void setLname(String lname) {
		this.lname = lname;
	}


	public String getPassword() {
		return password;
	}


	public void setPassword(String password) {
		this.password = password;
	}


	public String getEmail() {
		return email;
	}


	public void setEmail(String email) {
		this.email = email;
	}


	@Override
	public String toString() {
		return "Register [registerId=" + registerId + ", username=" + username + ", fname=" + fname + ", lname=" + lname
				+ ", password=" + password + ", email=" + email + "]";
	}
	
	
	
	
}

