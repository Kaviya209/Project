package com.userCrud.model;


import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="student")
public class Student {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
  private int studentId;
	
	@Column(name="fname")
	  private String fname;
	@Column(name="lname")
	  private String lname;
	@Column(name="city")
	  private String city;
	@Column(name="state")
	  private String state;
	@Column(name="zip")
	  private String zip;
	@Column(name="email")
     private String email;
	@Column(name="contactnum")
	  private String contactnum;
	@Column(name="gender")
	  private String gender;
	@Column(name="prfdays")
	  private String prfdays;
	@Column(name="prftime")
	  private String prftime;
	@Column(name="dob")
	  private String dob;
	@Column(name="cardname")
	  private String cardname;
	@Column(name="cardnum")
	  private String cardnum;
	@Column(name="expmonth")
	  private String expmonth;
	@Column(name="expyear")
	  private String expyear;
	@Column(name="cvvnum")
	  private String cvvnum;
	@Column (name="coursename")
	 private String coursename;
	  
	public Student() {
		
	}


	public Student(int studentId, String fname, String lname, String city, String state, String zip, String email,
			String contactnum, String gender, String prfdays, String prftime, String dob, String cardname,
			String cardnum, String expmonth, String expyear, String cvvnum, String coursename) {
		super();
		this.studentId = studentId;
		this.fname = fname;
		this.lname = lname;
		this.city = city;
		this.state = state;
		this.zip = zip;
		this.email = email;
		this.contactnum = contactnum;
		this.gender = gender;
		this.prfdays = prfdays;
		this.prftime = prftime;
		this.dob = dob;
		this.cardname = cardname;
		this.cardnum = cardnum;
		this.expmonth = expmonth;
		this.expyear = expyear;
		this.cvvnum = cvvnum;
		this.coursename = coursename;
	}


	public int getStudentId() {
		return studentId;
	}


	public void setStudentId(int studentId) {
		this.studentId = studentId;
	}


	public String getFname() {
		return fname;
	}


	public void setFname(String fname) {
		this.fname = fname;
	}


	public String getLname() {
		return lname;
	}


	public void setLname(String lname) {
		this.lname = lname;
	}


	public String getCity() {
		return city;
	}


	public void setCity(String city) {
		this.city = city;
	}


	public String getState() {
		return state;
	}


	public void setState(String state) {
		this.state = state;
	}


	public String getZip() {
		return zip;
	}


	public void setZip(String zip) {
		this.zip = zip;
	}


	public String getEmail() {
		return email;
	}


	public void setEmail(String email) {
		this.email = email;
	}


	public String getContactnum() {
		return contactnum;
	}


	public void setContactnum(String contactnum) {
		this.contactnum = contactnum;
	}


	public String getGender() {
		return gender;
	}


	public void setGender(String gender) {
		this.gender = gender;
	}


	public String getPrfdays() {
		return prfdays;
	}


	public void setPrfdays(String prfdays) {
		this.prfdays = prfdays;
	}


	public String getPrftime() {
		return prftime;
	}


	public void setPrftime(String prftime) {
		this.prftime = prftime;
	}


	public String getDob() {
		return dob;
	}


	public void setDob(String dob) {
		this.dob = dob;
	}


	public String getCardname() {
		return cardname;
	}


	public void setCardname(String cardname) {
		this.cardname = cardname;
	}


	public String getCardnum() {
		return cardnum;
	}


	public void setCardnum(String cardnum) {
		this.cardnum = cardnum;
	}


	public String getExpmonth() {
		return expmonth;
	}


	public void setExpmonth(String expmonth) {
		this.expmonth = expmonth;
	}


	public String getExpyear() {
		return expyear;
	}


	public void setExpyear(String expyear) {
		this.expyear = expyear;
	}


	public String getCvvnum() {
		return cvvnum;
	}


	public void setCvvnum(String cvvnum) {
		this.cvvnum = cvvnum;
	}
    
	

	public String getCoursename() {
		return coursename;
	}


	public void setCoursename(String coursename) {
		this.coursename = coursename;
	}


	@Override
	public String toString() {
		return "Student [studentId=" + studentId + ", fname=" + fname + ", lname=" + lname + ", city=" + city
				+ ", state=" + state + ", zip=" + zip + ", email=" + email + ", contactnum=" + contactnum + ", gender="
				+ gender + ", prfdays=" + prfdays + ", prftime=" + prftime + ", dob=" + dob + ", cardname=" + cardname
				+ ", cardnum=" + cardnum + ", expmonth=" + expmonth + ", expyear=" + expyear + ", cvvnum=" + cvvnum
				+ ", coursename=" + coursename + "]";
	}


	
	

}
